const STUDENT_PROFILE = "StudentProfile";

module.exports = {STUDENT_PROFILE};
