const ROLE = {
  Admin: 'Admin',
}

module.exports = {ROLE}